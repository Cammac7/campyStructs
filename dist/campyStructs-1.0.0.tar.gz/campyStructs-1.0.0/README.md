**campyStructs**

Classes for basic data structures in python. Intended primarily for educational use and use in conjunction with the python solutions to Cracking the Coding Interview located [here](https://github.com/Cammac7/CodingPractice/tree/master/python)

Various Structures Covered:

-Linked Lists
-Trees (to be implemented)
-Tries (to be implemented)
-Graph
-Stacks (to be implemented)
-Queue (to be implemented)
-Heaps (to be implemented)
